import 'package:flutter/material.dart';

class StackHome extends StatefulWidget{
  const StackHome({super.key});

  @override
  State<StackHome> createState() => _StackHomeState();
}

class _StackHomeState extends State<StackHome> {
  static const heading = '\$2300 per month';
  static const subheading = '2 beds, 1 bath, 1300 sqft';
  static const cardImage = NetworkImage('https://source.unplash.com/random/800x600?house');
  static const supportingText = 'Beautiful home to rent, recently refurbished with modern appliances...';

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4, 
      child: Scaffold(
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: const[
              DrawerHeader(
                decoration: BoxDecoration(color: Colors.blue),
                child: Text("Menu Principal"),
              ),
              ListTile(
                title: Text("Item 1"),
                onTap: null,
              ),
              ListTile(
                title: Text("Menu 2"), onTap: null,)
            ],
          )
        ),
        appBar: AppBar(
          title: const Text("Layouts"),
          bottom: const TabBar(tabs: [
            Tab(icon: Icon(Icons.directions_car)),
            Tab(icon: Icon(Icons.directions_transit)),
            Tab(icon: Icon(Icons.directions_bike)),
            Tab(icon: Icon(Icons.card_giftcard)),
          ]),
        ),
        body: TabBarView(children: [
          const Padding(
            padding: EdgeInsets.all(10.0),
            child: Column(
              children: [
                Text("El Buho",
                  style: 
                    TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                Column(
                  children: [
                    Image(
                      image: NetworkImage(
                        'https://flutter.github.io/assets-for-api-docs/assets/ widgets/owl.jpg'),
                    ),
                    Text(
                      "Buho es el nombre comun de aves de la familia Strigidae, del orden de los estrigiformes o aves rapaces",
                      textAlign: TextAlign.justify)
                  ],
                ),
              ],
            ),
          ),
          Stack(
            alignment: Alignment.center,
            children: <Widget>[
              const Image(
                width: 200,
                height: 200,
                image: NetworkImage('https://flutter.github.io/assets-for-api-docs/assets/ widgets/owl.jpg')
              ),
              Container(
                width: 90,
                height: 90,
                color: Colors.green,
              )
            ],
          )
          GridView.count(
            primary: false,
            padding: const EdgeInsets.all(20),
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            crossAxisCount: 2,
            children: <Widget>[
              Container(
                padding: const EdgeInsets.all(8),
                color: Colors.teal[100],
                child: const Text("He'd have you all unravel at the"),
              ),
              Container(
                padding: const EdgeInsets.all(8),
                color: Colors.teal[200],
                child: const Text("Heed not the rabble"),
              ),
              Container(
                padding: const EdgeInsets.all(8),
                color: Colors.teal[300],
                child: const Text("Sound of screams but the"),
              ),
              Container(
                padding: const EdgeInsets.all(8),
                color: Colors.teal[400],
                child: const Text("Who scream"),
              ),
              Container(
                padding: const EdgeInsets.all(8),
                color: Colors.teal[500],
                child: const Text("Revolution is coming..."),
              ),
              Container(
                padding: const EdgeInsets.all(8),
                color: Colors.teal[600],
                child: const Text("Revolution, they..."),
              ),
            ],
          ),
          Card(
            elevation: 4.0,
            child: Column(
              children: <Widget>[
                const ListTile(
                  title: Text(heading),
                  subtitle: Text(subheading),
                  trailing: Icon(Icons.favorite_outline),
                ),
                Container(
                  height: 200.0,
                  child: Ink.image(
                    image: cardImage,
                    fit: BoxFit.cover,),
                ),
                Container(
                  padding: const EdgeInsets.all(16.0),
                  alignment: Alignment.centerLeft,
                  child: const Text (supportingText),
                ),
                ButtonBar(
                  children: [
                    TextButton(
                      child: const Text ('CONTACT AGENT'),
                      onPressed: () {/* ... */},
                    ),
                    TextButton(
                      child: const Text ('LEARN MORE')
                      onPressed: () {/* ... */},
                      ),
                  ],
                )
              ],
            ),
          )
        ]),
        floatingActionButton: FloatingActionButton(
          onPressed: (){
            final snackBar=SnackBar(
              content: const Text('Hola! Soy una SnackBar!'),
              action: SnackBarAction(
                label: 'Undo', 
                onPressed: (){
                },
              ),
            );
            ScaffoldMessenger.of(context).showSnackBar(snackBar);
          },
          child: const Icon(Icons.add),
        ),
      )
    );
  }
}































